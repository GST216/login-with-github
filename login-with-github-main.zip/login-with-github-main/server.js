const express = require("express");
var bodyParser = require('body-parser')
const app = express();

const GITHUB_CLIENT_ID = "";
const GITHUB_CLIENT_SECRET = "";
app.listen(4001, () => {
  console.log(`app is listeneing to port 4001`);
});
app.get("/oauth-callback", (req, res) => {
    console.log(req);
});
