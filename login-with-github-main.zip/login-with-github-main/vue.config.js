module.exports={
    devServer:{
        proxy:"http://locahost:4001/"
    }
}