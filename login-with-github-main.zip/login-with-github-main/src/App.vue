<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logoi.png">
    <a  style="color:black;text-decoration:none;cursor:pointer;display:block;" href="https://github.com/login/oauth/authorize?client_id=20084b20d792cb61c106&redirect_url=/oauth-callback&path='/'">login with github</a>
  </div>
</template>

<script>

export default {
  name: 'App',
  components: {
  },
  data(){
    return {
      client_id:"20084b20d792cb61c106",
      repos:[],
      redirectUrl:'/oauth-callback',
      path:'/'
    }
  },
  mounted(){
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
